import React from "react";

const Footer = () => {
  return (
    <div
      style={{
        height: "72px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
      }}
    >
      <div>Movie App</div>
      <div>@2024,Movie,Inc. or its affiliates</div>
    </div>
  );
};

export default Footer;
