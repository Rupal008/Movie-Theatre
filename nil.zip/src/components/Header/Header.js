import React from 'react';
import { Link } from 'react-router-dom';
import { useState } from "react";
import nilesh1 from "./nilesh1.jpeg"

const nilesh12 = require("./nilesh12.png");

const Header = () => {
    const [sortedBy, setSortedBy] = useState("");
    return (
        <div style={{ background:'#0f171e',color:'white',height:'72px',padding:'0px 40px ', display:'flex',alignItems:'center',justifyContent:"space-between"}}>
            <Link to="/">
            {/* <div style={{fontSize:'20px',fontWeight:'600'}}> Movie App</div> */}
            <img
            src={nilesh12}
            alt=""
            style={{ width: "30%", height: "10%"}}
          ></img>
            </Link>
            {/* <Link to="/lag" className='tracking-wider text-white ml-96'>English</Link> */}
            <select
            value={sortedBy}
            onChange={(e) => setSortedBy(e.target.value)}
            className='bg-gray-300 text-black ml-96 px-1 py-1 rounded-sm'
          >
            <option value="eng">English</option>
            <option value="mar">Marathi</option>
            
          </select>
            <Link to='/signin' className='tracking-wider text-white mr-20  bg-red-600 px-2 py-1 rounded-md'>Sign In</Link>
            {/* <div>
                <img src={nilesh1} style={{width:"38px",height:'38px'}} className='rounded-full mr-20' alt='user'/>
            </div> */}
        </div>
    );
};

export default Header;