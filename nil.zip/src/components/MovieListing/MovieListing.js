import React from "react";
import { useSelector } from "react-redux";
import { getAllMovies } from "../../features/movies/movieSlice";
import MovieCard from "../MovieCard/MovieCard";
import "./MovieListing.css";
import nilesh from "./nilesh.png";

const MovieListing = () => {
  const movies = useSelector(getAllMovies);
  let renderMovies = "";
  console.log("movies", movies);
  renderMovies =
    movies.Response === "True" ? (
      movies.Search.map((movie, index) => (
        <MovieCard key={index} data={movie} />
      ))
    ) : (
      <div className="movies-error">
        <h3>{movies.Error}</h3>
      </div>
    );
  return (
    <div className="movie-wrapper cursor-pointer">
      <div className="ml-20 mr-20">
        <div className="row ">
          <img
            src={nilesh}
            alt=""
            style={{ width: "100%", height: "20%", opacity: "0.30" }}
          ></img>
          <div className="img-text mt-56 " style={{ marginLeft: "450px" }}>
            <p className="text-center text-6xl tracking-wider mt-3  font-semibold text-white">
              WELCOME.
            </p>
            <p className="text-center text-2xl tracking-wider font-semibold text-white">
            The biggest Indian hits. Ready to watch here
            </p>
            <p className="text-center text-2xl tracking-wider font-semibold text-white">
            from ₹149.
            </p>
            <p className="text-center text-sm tracking-wider font-semibold text-white">
            Join today. Cancel anytime.
            </p>
            <p className="text-center text-sm tracking-wider font-semibold text-white">
            Ready to watch? Enter your email to create or restart your membership.
            </p>
            <div className=" flex flex-center m-auto  mt-2  items-center justify-center bg-gray-200 rounded-2xl">
              <input
                type="text"
                name="text"
                placeholder="write your favorite movie..."
                className=" flex flex-center m-auto  items-center justify-center bg-gray-200 rounded-2xl"
              />
              <div
                className="text-black py-1 ms-auto rounded-r-2xl tracking-wider  text-center w-20 inline"
                style={{ background: "hsl(22 94% 63% / 1)",cursor:'pointer' }}
              >
                Search
              </div>
            </div>
          </div>
        </div>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))",
            gridGap: "15px",
          }}
        >
          {renderMovies}
        </div>
      </div>
    </div>
  );
};

export default MovieListing;
