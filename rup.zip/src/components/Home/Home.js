import React from 'react';
import { useEffect } from 'react';
import MovieListing from "../MovieListing/MovieListing"
import movieApi from '../../common/apis/movieApi';
import {APIKey} from '../../common/apis/MovieApiKey';
import { useDispatch } from 'react-redux';
import { addMovies } from '../../features/movies/movieSlice';
const Home = () => {

    const movieText = 'Harry Potter';
    const dispatch =useDispatch();

    useEffect(()=>{
        const fetchMovies = async ()=>{
            const response = await movieApi
            .get(`?apiKey=${APIKey}&s=${movieText}&type=movie`)
            .catch((err)=>{
                console.log('Err :',err)
            });
            // console.log("the response from api",response);
            dispatch(addMovies(response.data));
        };
        fetchMovies();
    }, []);

    return (
        <div>
            <div style={{}}></div>
            <MovieListing/>
        </div>
    );
};

export default Home;